﻿using CoreXF.Abstractions;

namespace WebAppTS
{
    public class Extension : ExtensionBase
    {
        public override string Name => nameof(WebAppTS);
    }
}